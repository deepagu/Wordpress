UPDATE PLUGIN
If you installed plugin on your site and want update, please do step by step:
1. Unzip file "update_plugin.zip"
3. Upload all folders "wp-content", "tshirtecommerce" to main folder of your site.


INSTALL NEW PLUGIN
Please choose file plugin_tshirtecommerce.zip to install.
Please read detail in file documents/index.html